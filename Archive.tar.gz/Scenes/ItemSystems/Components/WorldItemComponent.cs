using System;
using Godot;

public partial class WorldItemComponent : Node
{
    [Export] public string ItemID;

}
