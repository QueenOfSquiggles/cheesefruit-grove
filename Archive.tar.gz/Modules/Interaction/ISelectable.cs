namespace Modules.Interaction;

public interface ISelectable
{
    void OnSelect();
    void OnDeselect();
}
