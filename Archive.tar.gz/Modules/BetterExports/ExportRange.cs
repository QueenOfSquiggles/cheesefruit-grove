// using Godot;

// namespace Modules.BetterExports;


// TODO if ExportAttribute is changed to a non-sealed class, create extension with better usability
// [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
// public class ExportRange : ExportAttribute
// {

// }
