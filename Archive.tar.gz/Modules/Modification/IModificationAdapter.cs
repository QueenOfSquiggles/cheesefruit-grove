namespace queen.modification;
public interface IModificationAdapter
{

    void OnRegister();
    void OnUnRegister();

}